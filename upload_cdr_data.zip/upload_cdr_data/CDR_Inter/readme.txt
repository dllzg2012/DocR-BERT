Line 1:
CTD Knowledge@chemical@disease
pubmed ID
label
Title(before replace)
Title(replaced)
Abstract
label|checmical id|disease id
co-occurrence sentence(s)

Line 2: Dependency Path

Line 3: distance of chemical entity-sentence relative to the nearest co-occurrence sentence 
Line 4: distance of disease entity-sentence relative to the nearest co-occurrence sentence 
Line 5-N: all sentences
